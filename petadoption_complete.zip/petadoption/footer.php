</div><!-- end container -->

<footer>
  <strong>Pet Adoption &amp; Care System</strong> &nbsp;|&nbsp;
  RDBMS Lab CA Activity 1 &nbsp;|&nbsp;
  PHP (XAMPP) + PostgreSQL (pgAdmin) &nbsp;|&nbsp;
  <span style="color:#cfe2ff;">22 Tables &nbsp;•&nbsp; 4 Specializations &nbsp;•&nbsp; 3 Triggers &nbsp;•&nbsp; 3 Views</span>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
