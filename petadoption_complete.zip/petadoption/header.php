<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Pet Adoption System</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"/>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet"/>
  <style>
    body { background:#f0f4f8; font-family:'Segoe UI',sans-serif; }

    .navbar { background:linear-gradient(135deg,#1a3a5c,#2e75b6); }
    .navbar-brand { color:#fff !important; font-weight:700; font-size:1.2rem; }
    .nav-link { color:#cfe2ff !important; }
    .nav-link:hover, .nav-link.active { color:#fff !important; font-weight:600; }

    .page-header {
      background:linear-gradient(135deg,#1a3a5c,#2e75b6);
      color:#fff; border-radius:12px; padding:22px 28px; margin-bottom:24px;
    }
    .page-header h4 { margin:0; font-weight:700; }
    .page-header small { opacity:.85; }

    .card { border:none; border-radius:12px; box-shadow:0 2px 14px rgba(0,0,0,.09); }
    .card-header { border-radius:12px 12px 0 0 !important; font-weight:600; font-size:.95rem; }

    .table thead th { background:#1a3a5c; color:#fff; border:none; font-weight:600; }
    .table tbody tr:hover { background:#e8f0fe; }

    /* CRUD button colours */
    .btn-create { background:#198754; color:#fff; border:none; }
    .btn-create:hover { background:#146c43; color:#fff; }
    .btn-read   { background:#0d6efd; color:#fff; border:none; }
    .btn-read:hover { background:#0b5ed7; color:#fff; }
    .btn-update { background:#fd7e14; color:#fff; border:none; }
    .btn-update:hover { background:#dc6c00; color:#fff; }
    .btn-delete { background:#dc3545; color:#fff; border:none; }
    .btn-delete:hover { background:#b02a37; color:#fff; }

    .badge-available { background:#198754!important; }
    .badge-adopted   { background:#6c757d!important; }
    .badge-reserved  { background:#fd7e14!important; }

    .before-box { background:#fff3cd; border-left:4px solid #fd7e14; padding:14px 18px; border-radius:8px; }
    .after-box  { background:#d1e7dd; border-left:4px solid #198754; padding:14px 18px; border-radius:8px; }

    .sql-box { background:#2b2b2b; color:#f8f8f2; border-radius:8px;
               padding:14px 18px; font-family:monospace; font-size:.82rem; }

    .sidebar-link { display:block; padding:9px 14px; border-radius:8px;
                    color:#1a3a5c; text-decoration:none; font-weight:500; margin-bottom:4px; }
    .sidebar-link:hover, .sidebar-link.active { background:#2e75b6; color:#fff; }
    .sidebar-link i { margin-right:8px; }

    footer { background:#1a3a5c; color:#9dc3e6; text-align:center;
             padding:14px; margin-top:40px; font-size:.85rem; }
  </style>
</head>
<body>

<nav class="navbar navbar-expand-lg px-4 py-2 mb-0">
  <a class="navbar-brand" href="index.php">
    <i class="bi bi-heart-fill me-2" style="color:#ff6b8a;"></i>Pet Adoption System
  </a>
  <div class="ms-auto d-flex gap-3">
    <a class="nav-link" href="index.php"><i class="bi bi-house me-1"></i>Home</a>
    <a class="nav-link" href="pets.php"><i class="bi bi-grid me-1"></i>Pets</a>
    <a class="nav-link" href="adopters.php"><i class="bi bi-people me-1"></i>Adopters</a>
    <a class="nav-link" href="applications.php"><i class="bi bi-file-earmark-text me-1"></i>Applications</a>
    <a class="nav-link" href="appointments.php"><i class="bi bi-calendar-check me-1"></i>Appointments</a>
    <a class="nav-link" href="providers.php"><i class="bi bi-hospital me-1"></i>Providers</a>
    <a class="nav-link" href="staff.php"><i class="bi bi-person-badge me-1"></i>Staff</a>
    <a class="nav-link" href="donations.php"><i class="bi bi-cash-coin me-1"></i>Donations</a>
    <a class="nav-link" href="views.php"><i class="bi bi-eye me-1"></i>Views</a>
  </div>
</nav>

<div class="container-fluid px-4 py-3">
<?php
// Flash message display
if (isset($_SESSION['msg'])) {
    $type = $_SESSION['msg_type'] ?? 'success';
    echo "<div class='alert alert-{$type} alert-dismissible fade show'>
          {$_SESSION['msg']}
          <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
          </div>";
    unset($_SESSION['msg'], $_SESSION['msg_type']);
}
?>
