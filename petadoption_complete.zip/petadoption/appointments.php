<?php
// ── APPOINTMENTS ─────────────────────────────────────────────────────────────
session_start(); require 'db.php'; $conn = getDB();
$action = $_GET['action'] ?? 'list';

if ($action==='delete' && isset($_GET['id'])) {
    $id=esc($conn,$_GET['id']);
    if ($_SERVER['REQUEST_METHOD']==='POST') {
        pg_query($conn,"DELETE FROM Appointments WHERE appointment_id='$id'");
        $_SESSION['msg']="Appointment {$id} deleted."; $_SESSION['msg_type']='success';
        header('Location: appointments.php'); exit;
    }
    require 'header.php';
    $r=pg_query($conn,"SELECT * FROM Appointments WHERE appointment_id='$id'"); $row=pg_fetch_assoc($r);
    echo "<div class='page-header'><h4>DELETE — Confirm Appointment Deletion</h4></div>";
    echo "<div class='row justify-content-center'><div class='col-lg-5'><div class='card border-danger'><div class='card-header bg-danger text-white'>Confirm Delete — {$id}</div><div class='card-body'>";
    foreach($row as $k=>$v) echo "<div><strong>{$k}:</strong> ".htmlspecialchars($v??'—')."</div>";
    echo "<div class='sql-box my-3'>DELETE FROM Appointments WHERE appointment_id = '{$id}';</div>";
    echo "<div class='alert alert-warning mt-2'><i class='bi bi-lightning-fill me-2'></i>Note: The BEFORE INSERT trigger <code>trg_check_pet_status</code> prevents adding appointments for adopted pets — this delete removes an existing one.</div>";
    echo "<div class='d-flex gap-3'><form method='POST' class='flex-fill'><button class='btn btn-delete w-100 py-2'>Yes, Delete</button></form><a href='appointments.php' class='btn btn-outline-secondary flex-fill py-2'>Cancel</a></div></div></div></div></div>";
    require 'footer.php'; exit;
}

if ($action==='add' || $action==='edit') {
    $ap=[];
    if ($action==='edit' && isset($_GET['id'])) {
        $id=esc($conn,$_GET['id']); $r=pg_query($conn,"SELECT * FROM Appointments WHERE appointment_id='$id'"); $ap=pg_fetch_assoc($r)?:[];
    }
    $pets = pg_fetch_all(pg_query($conn,"SELECT pet_id,name,adoption_status FROM Pets WHERE adoption_status<>'Adopted' ORDER BY name"));
    $provs= pg_fetch_all(pg_query($conn,"SELECT provider_id,name FROM Pet_Care_Providers ORDER BY name"));
    if ($_SERVER['REQUEST_METHOD']==='POST') {
        $apid=esc($conn,$_POST['appointment_id']); $dt=esc($conn,$_POST['appointment_date']);
        $svc=esc($conn,$_POST['service_type']); $dur=(int)$_POST['duration_mins'];
        $nt=esc($conn,$_POST['notes']); $pid=esc($conn,$_POST['pet_id']); $prid=esc($conn,$_POST['provider_id']);
        if ($action==='add') {
            $q=pg_query($conn,"INSERT INTO Appointments VALUES ('$apid','$dt','$svc',$dur,'$nt','$pid','$prid')");
            if(!$q) { $_SESSION['msg']="Error: ".pg_last_error($conn)." (Check: trigger blocks appointments for adopted pets)"; $_SESSION['msg_type']='danger'; }
            else { $_SESSION['msg']="Appointment {$apid} added."; $_SESSION['msg_type']='success'; }
        } else {
            $before_r=pg_query($conn,"SELECT * FROM Appointments WHERE appointment_id='$apid'"); $before=pg_fetch_assoc($before_r);
            pg_query($conn,"UPDATE Appointments SET appointment_date='$dt',service_type='$svc',duration_mins=$dur,notes='$nt',pet_id='$pid',provider_id='$prid' WHERE appointment_id='$apid'");
            $after_r=pg_query($conn,"SELECT * FROM Appointments WHERE appointment_id='$apid'"); $after=pg_fetch_assoc($after_r);
            $_SESSION['before']=$before; $_SESSION['after']=$after;
            $_SESSION['sql']="UPDATE Appointments SET appointment_date='$dt', service_type='$svc'\nWHERE appointment_id = '$apid';";
            header('Location: update_result.php'); exit;
        }
        header('Location: appointments.php'); exit;
    }
    require 'header.php';
    echo "<div class='page-header'><h4>".($action==='add'?'CREATE — Add Appointment':'UPDATE — Edit Appointment')."</h4>
    <small>⚡ BEFORE INSERT trigger blocks appointments for already-adopted pets</small></div>";
    echo "<div class='row justify-content-center'><div class='col-lg-7'><div class='card'><div class='card-header' style='background:".($action==='add'?'#198754':'#fd7e14').";color:#fff;'>Appointment Form</div><div class='card-body p-4'>";
    echo "<form method='POST'><div class='row g-3'>";
    echo "<div class='col-md-4'><label class='form-label fw-semibold'>Appointment ID *</label><input name='appointment_id' class='form-control' value='".htmlspecialchars($ap['appointment_id']??'')."' ".($action==='edit'?'readonly':'')." required/></div>";
    echo "<div class='col-md-4'><label class='form-label fw-semibold'>Date *</label><input name='appointment_date' type='date' class='form-control' value='".($ap['appointment_date']??date('Y-m-d'))."' required/></div>";
    echo "<div class='col-md-4'><label class='form-label fw-semibold'>Duration (mins)</label><input name='duration_mins' type='number' class='form-control' value='".($ap['duration_mins']??30)."'/></div>";
    echo "<div class='col-md-6'><label class='form-label fw-semibold'>Service Type *</label><input name='service_type' class='form-control' value='".htmlspecialchars($ap['service_type']??'')."' required placeholder='e.g. Vaccination, Grooming'/></div>";
    echo "<div class='col-md-6'><label class='form-label fw-semibold'>Pet (non-adopted only)</label><select name='pet_id' class='form-select'>";
    foreach($pets as $p) echo "<option value='{$p['pet_id']}' ".($ap['pet_id']??'')===$p['pet_id']?'selected':''.">{$p['pet_id']} — ".htmlspecialchars($p['name'])." ({$p['adoption_status']})</option>";
    echo "</select></div><div class='col-md-6'><label class='form-label fw-semibold'>Provider</label><select name='provider_id' class='form-select'>";
    foreach($provs as $pv) echo "<option value='{$pv['provider_id']}' ".($ap['provider_id']??'')===$pv['provider_id']?'selected':''.">{$pv['provider_id']} — ".htmlspecialchars($pv['name'])."</option>";
    echo "</select></div><div class='col-12'><label class='form-label fw-semibold'>Notes</label><textarea name='notes' class='form-control' rows='2'>".htmlspecialchars($ap['notes']??'')."</textarea></div>";
    echo "</div><div class='sql-box my-3'>INSERT INTO Appointments VALUES (...);\n-- trg_check_pet_status fires BEFORE INSERT\n-- blocks if pet is already adopted</div>";
    echo "<div class='d-flex gap-3 mt-2'><button class='btn ".($action==='add'?'btn-create':'btn-update')." flex-fill py-2'>Save</button><a href='appointments.php' class='btn btn-outline-secondary flex-fill py-2'>Cancel</a></div></form></div></div></div></div>";
    require 'footer.php'; exit;
}

$res=pg_query($conn,"SELECT a.*, p.name AS pet_name, pcp.name AS provider_name
FROM Appointments a JOIN Pets p ON a.pet_id=p.pet_id
JOIN Pet_Care_Providers pcp ON a.provider_id=pcp.provider_id ORDER BY a.appointment_date DESC");
$rows=pg_fetch_all($res)?:[];
require 'header.php';
?>
<div class="page-header"><h4><i class="bi bi-calendar-check me-2"></i>Appointments — CRUD</h4>
<small>Weak entity linking Pets and Pet_Care_Providers &nbsp;|&nbsp; ⚡ BEFORE INSERT trigger: blocks appointments for adopted pets</small></div>
<div class="mb-3"><a href="appointments.php?action=add" class="btn btn-create"><i class="bi bi-plus-circle me-2"></i>New Appointment</a></div>
<div class="card"><div class="card-header d-flex justify-content-between" style="background:#1a3a5c;color:#fff;">
<span><i class="bi bi-table me-2"></i>Appointments Table</span><span class="badge bg-light text-dark"><?=count($rows)?> record(s)</span>
</div><div class="card-body p-0"><div class="table-responsive">
<table class="table table-hover table-bordered mb-0"><thead><tr>
<th>Appt ID</th><th>Date</th><th>Pet</th><th>Provider</th><th>Service</th><th>Duration</th><th>Notes</th><th class="text-center">Actions</th>
</tr></thead><tbody>
<?php foreach($rows as $r): ?>
<tr>
<td><code><?=htmlspecialchars($r['appointment_id'])?></code></td>
<td><?=$r['appointment_date']?></td>
<td><strong><?=htmlspecialchars($r['pet_name'])?></strong></td>
<td><?=htmlspecialchars($r['provider_name'])?></td>
<td><span class="badge bg-info text-dark"><?=htmlspecialchars($r['service_type'])?></span></td>
<td><?=$r['duration_mins']?> min</td>
<td><small><?=htmlspecialchars(substr($r['notes']??'—',0,30))?></small></td>
<td class="text-center text-nowrap">
<a href="appointments.php?action=edit&id=<?=urlencode($r['appointment_id'])?>" class="btn btn-update btn-sm me-1"><i class="bi bi-pencil-square"></i></a>
<a href="appointments.php?action=delete&id=<?=urlencode($r['appointment_id'])?>" class="btn btn-delete btn-sm"><i class="bi bi-trash3"></i></a>
</td></tr>
<?php endforeach; ?>
</tbody></table></div></div></div>
<?php pg_close($conn); require 'footer.php'; ?>
