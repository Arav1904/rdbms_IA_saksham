<?php session_start(); require 'db.php'; $conn = getDB(); require 'header.php'; ?>
<div class="page-header">
  <h4><i class="bi bi-eye me-2"></i>SQL Views — Pet Adoption System</h4>
  <small>3 views defined in the database: Available_Pets, Pending_Applications_View, Pet_Appointment_History</small>
</div>

<!-- View 1: Available_Pets -->
<div class="card mb-4">
  <div class="card-header" style="background:#198754;color:#fff;">
    <i class="bi bi-eye me-2"></i>View 1: Available_Pets
    <span class="badge bg-light text-dark ms-2">Simple View — single table</span>
  </div>
  <div class="card-body">
    <div class="sql-box mb-3">CREATE OR REPLACE VIEW Available_Pets AS<br/>
SELECT pet_id, name, breed, age, gender, adoption_status<br/>
FROM Pets WHERE adoption_status = 'Available';</div>
    <?php
    $res = pg_query($conn,"SELECT * FROM Available_Pets ORDER BY pet_id");
    $rows = pg_fetch_all($res)?:[];
    ?>
    <div class="table-responsive">
    <table class="table table-hover table-bordered mb-0"><thead><tr>
      <?php if($rows) foreach(array_keys($rows[0]) as $col) echo "<th>{$col}</th>"; ?>
    </tr></thead><tbody>
    <?php foreach($rows as $r): ?>
    <tr><?php foreach($r as $v) echo "<td>".htmlspecialchars($v??'—')."</td>"; ?></tr>
    <?php endforeach; ?>
    </tbody></table>
    </div>
    <small class="text-muted mt-2 d-block"><?=count($rows)?> rows returned</small>
  </div>
</div>

<!-- View 2: Pending_Applications_View -->
<div class="card mb-4">
  <div class="card-header" style="background:#0d6efd;color:#fff;">
    <i class="bi bi-eye me-2"></i>View 2: Pending_Applications_View
    <span class="badge bg-light text-dark ms-2">Complex View — 3-table JOIN</span>
  </div>
  <div class="card-body">
    <div class="sql-box mb-3">CREATE OR REPLACE VIEW Pending_Applications_View AS<br/>
SELECT aa.application_id, aa.application_date, p.name AS pet_name, p.breed,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ad.first_name || ' ' || ad.last_name AS adopter_name, ad.phone<br/>
FROM Adoption_Applications aa<br/>
JOIN Pets p ON aa.pet_id = p.pet_id<br/>
JOIN Adopters ad ON aa.adopter_id = ad.adopter_id<br/>
WHERE aa.status = 'Pending';</div>
    <?php
    $res2 = pg_query($conn,"SELECT * FROM Pending_Applications_View");
    $rows2 = pg_fetch_all($res2)?:[];
    ?>
    <div class="table-responsive">
    <table class="table table-hover table-bordered mb-0"><thead><tr>
      <?php if($rows2) foreach(array_keys($rows2[0]) as $col) echo "<th>{$col}</th>"; ?>
    </tr></thead><tbody>
    <?php foreach($rows2 as $r): ?>
    <tr><?php foreach($r as $v) echo "<td>".htmlspecialchars($v??'—')."</td>"; ?></tr>
    <?php endforeach; ?>
    </tbody></table>
    </div>
    <small class="text-muted mt-2 d-block"><?=count($rows2)?> rows returned</small>
  </div>
</div>

<!-- View 3: Pet_Appointment_History -->
<div class="card mb-4">
  <div class="card-header" style="background:#6f42c1;color:#fff;">
    <i class="bi bi-eye me-2"></i>View 3: Pet_Appointment_History
    <span class="badge bg-light text-dark ms-2">Complex View — 3-table JOIN</span>
  </div>
  <div class="card-body">
    <div class="sql-box mb-3">CREATE OR REPLACE VIEW Pet_Appointment_History AS<br/>
SELECT p.name AS pet_name, p.breed, a.appointment_date,<br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; a.service_type, a.duration_mins, pcp.name AS provider_name, pcp.visiting_fee<br/>
FROM Appointments a<br/>
JOIN Pets p ON a.pet_id = p.pet_id<br/>
JOIN Pet_Care_Providers pcp ON a.provider_id = pcp.provider_id;</div>
    <?php
    $res3 = pg_query($conn,"SELECT * FROM Pet_Appointment_History ORDER BY appointment_date DESC");
    $rows3 = pg_fetch_all($res3)?:[];
    ?>
    <div class="table-responsive">
    <table class="table table-hover table-bordered mb-0"><thead><tr>
      <?php if($rows3) foreach(array_keys($rows3[0]) as $col) echo "<th>{$col}</th>"; ?>
    </tr></thead><tbody>
    <?php foreach($rows3 as $r): ?>
    <tr><?php foreach($r as $v) echo "<td>".htmlspecialchars($v??'—')."</td>"; ?></tr>
    <?php endforeach; ?>
    </tbody></table>
    </div>
    <small class="text-muted mt-2 d-block"><?=count($rows3)?> rows returned</small>
  </div>
</div>

<!-- Triggers summary -->
<div class="card mb-4">
  <div class="card-header" style="background:#dc3545;color:#fff;"><i class="bi bi-lightning-fill me-2"></i>Triggers Implemented</div>
  <div class="card-body">
    <table class="table table-bordered">
      <thead><tr><th>Trigger Name</th><th>Fires</th><th>What It Does</th></tr></thead>
      <tbody>
        <tr><td><code>trg_approval_status</code></td><td>AFTER UPDATE on Adoption_Applications</td><td>When status → 'Approved', sets pet's adoption_status = 'Adopted' automatically</td></tr>
        <tr class="table-light"><td><code>trg_check_pet_status</code></td><td>BEFORE INSERT on Appointments</td><td>Blocks the insert if the pet is already 'Adopted' — raises an error</td></tr>
        <tr><td><code>trg_log_application</code></td><td>AFTER INSERT on Adoption_Applications</td><td>Writes a log row to Application_Audit table with timestamp</td></tr>
      </tbody>
    </table>
    <?php
    $audit = pg_fetch_all(pg_query($conn,"SELECT * FROM Application_Audit ORDER BY logged_at DESC LIMIT 10"))?:[];
    if ($audit):
    ?>
    <h6 class="mt-3 fw-bold">Latest Application_Audit entries (from trigger):</h6>
    <div class="table-responsive">
    <table class="table table-sm table-bordered"><thead><tr>
      <?php foreach(array_keys($audit[0]) as $col) echo "<th>{$col}</th>"; ?>
    </tr></thead><tbody>
    <?php foreach($audit as $a): ?>
    <tr><?php foreach($a as $v) echo "<td>".htmlspecialchars($v??'—')."</td>"; ?></tr>
    <?php endforeach; ?>
    </tbody></table></div>
    <?php endif; ?>
  </div>
</div>

<?php pg_close($conn); require 'footer.php'; ?>
