<?php
session_start();
$before = $_SESSION['before'] ?? [];
$after  = $_SESSION['after']  ?? [];
$sql    = $_SESSION['sql']    ?? '';
unset($_SESSION['before'], $_SESSION['after'], $_SESSION['sql']);
require 'header.php';
?>
<div class="page-header">
  <h4><i class="bi bi-check2-circle me-2"></i>UPDATE — Record Updated Successfully</h4>
  <small>Before and after comparison for Pet ID: <strong><?= htmlspecialchars($after['pet_id']??'') ?></strong></small>
</div>

<div class="row justify-content-center"><div class="col-lg-10">

  <div class="alert alert-success mb-4">
    <i class="bi bi-check-circle-fill me-2"></i>
    <strong>Success!</strong> Record updated in the <strong>Pets</strong> table.
    Fields highlighted in <span class="text-success fw-bold">green</span> were changed.
  </div>

  <div class="row g-4 mb-4">
    <div class="col-md-6">
      <div class="card h-100">
        <div class="card-header" style="background:#fd7e14;color:#fff;"><i class="bi bi-arrow-left-circle me-2"></i>BEFORE Update</div>
        <div class="card-body before-box">
          <table class="table table-sm table-borderless mb-0">
          <?php foreach($before as $k=>$v): ?>
          <tr><th width="45%" class="text-muted"><?= $k ?></th>
              <td><?= htmlspecialchars($v??'—') ?></td></tr>
          <?php endforeach; ?>
          </table>
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="card h-100">
        <div class="card-header" style="background:#198754;color:#fff;"><i class="bi bi-arrow-right-circle me-2"></i>AFTER Update</div>
        <div class="card-body after-box">
          <table class="table table-sm table-borderless mb-0">
          <?php foreach($after as $k=>$v):
            $changed = ($before[$k]??null) !== $v; ?>
          <tr><th width="45%" class="text-muted"><?= $k ?></th>
              <td <?= $changed?'class="fw-bold text-success"':'' ?>>
                <?= htmlspecialchars($v??'—') ?>
                <?= $changed?' <i class="bi bi-arrow-left-short text-success"></i>':'' ?>
              </td></tr>
          <?php endforeach; ?>
          </table>
        </div>
      </div>
    </div>
  </div>

  <div class="sql-box mb-4"><strong style="color:#50fa7b;">-- SQL Executed:</strong><br/><?= nl2br(htmlspecialchars($sql)) ?></div>

  <a href="pets.php" class="btn btn-read px-4 py-2"><i class="bi bi-arrow-left me-2"></i>Back to Pets</a>
</div></div>

<?php require 'footer.php'; ?>
