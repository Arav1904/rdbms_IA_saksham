<?php
session_start(); require 'db.php'; $conn = getDB();
$action = $_GET['action'] ?? 'list';

if ($action==='delete' && isset($_GET['id'])) {
    $id=esc($conn,$_GET['id']);
    if ($_SERVER['REQUEST_METHOD']==='POST') {
        pg_query($conn,"DELETE FROM Adoption_Applications WHERE application_id='$id'");
        $_SESSION['msg']="Application {$id} deleted."; $_SESSION['msg_type']='success';
        header('Location: applications.php'); exit;
    }
    require 'header.php';
    $r=pg_query($conn,"SELECT aa.*, p.name AS pet_name, ad.first_name||' '||ad.last_name AS adopter_name
        FROM Adoption_Applications aa JOIN Pets p ON aa.pet_id=p.pet_id
        JOIN Adopters ad ON aa.adopter_id=ad.adopter_id WHERE application_id='$id'");
    $row=pg_fetch_assoc($r);
    echo "<div class='page-header'><h4><i class='bi bi-trash3-fill me-2'></i>DELETE — Confirm Application Deletion</h4></div>";
    echo "<div class='row justify-content-center'><div class='col-lg-5'><div class='card border-danger'>
    <div class='card-header bg-danger text-white'>Confirm Delete — {$id}</div><div class='card-body'>
    <div class='alert alert-warning'>This will permanently remove application {$id}.</div>";
    foreach($row as $k=>$v) echo "<div><strong>{$k}:</strong> ".htmlspecialchars($v??'—')."</div>";
    echo "<div class='sql-box my-3'>DELETE FROM Adoption_Applications WHERE application_id = '{$id}';</div>
    <div class='d-flex gap-3'><form method='POST' class='flex-fill'><button class='btn btn-delete w-100 py-2'>Yes, Delete</button></form>
    <a href='applications.php' class='btn btn-outline-secondary flex-fill py-2'>Cancel</a></div>
    </div></div></div></div>";
    require 'footer.php'; exit;
}

if ($action==='add' || $action==='edit') {
    $ap=[];
    if ($action==='edit' && isset($_GET['id'])) {
        $id=esc($conn,$_GET['id']);
        $r=pg_query($conn,"SELECT * FROM Adoption_Applications WHERE application_id='$id'"); $ap=pg_fetch_assoc($r)?:[];
    }
    $pets     = pg_fetch_all(pg_query($conn,"SELECT pet_id,name,adoption_status FROM Pets ORDER BY name"));
    $adopters = pg_fetch_all(pg_query($conn,"SELECT adopter_id, first_name||' '||last_name AS full_name FROM Adopters ORDER BY first_name"));
    if ($_SERVER['REQUEST_METHOD']==='POST') {
        $appid=esc($conn,$_POST['application_id']); $dt=esc($conn,$_POST['application_date']);
        $st=esc($conn,$_POST['status']); $nt=esc($conn,$_POST['notes']);
        $adid=esc($conn,$_POST['adopter_id']); $pid=esc($conn,$_POST['pet_id']);
        if ($action==='add') {
            $q=pg_query($conn,"INSERT INTO Adoption_Applications VALUES ('$appid','$dt','$st','$nt','$adid','$pid')");
            if(!$q) { $_SESSION['msg']="Error: ".pg_last_error($conn); $_SESSION['msg_type']='danger'; }
            else { $_SESSION['msg']="Application {$appid} added. Audit log entry created automatically by trigger."; }
        } else {
            $before_r=pg_query($conn,"SELECT * FROM Adoption_Applications WHERE application_id='$appid'"); $before=pg_fetch_assoc($before_r);
            pg_query($conn,"UPDATE Adoption_Applications SET application_date='$dt',status='$st',notes='$nt',adopter_id='$adid',pet_id='$pid' WHERE application_id='$appid'");
            $after_r=pg_query($conn,"SELECT * FROM Adoption_Applications WHERE application_id='$appid'"); $after=pg_fetch_assoc($after_r);
            $_SESSION['before']=$before; $_SESSION['after']=$after;
            $_SESSION['sql']="UPDATE Adoption_Applications SET status='$st'\nWHERE application_id = '$appid';\n-- If status changed to 'Approved', trigger trg_approval_status\n-- automatically sets pet {$pid} adoption_status = 'Adopted'";
            header('Location: update_result.php'); exit;
        }
        $_SESSION['msg_type']='success';
        header('Location: applications.php'); exit;
    }
    require 'header.php';
    $title=$action==='add'?'CREATE — New Application':'UPDATE — Edit Application';
?>
<div class="page-header"><h4><?=$title?></h4>
<small>⚡ When status is set to "Approved", <strong>Trigger trg_approval_status</strong> automatically updates the pet's adoption_status to "Adopted"</small></div>
<div class="row justify-content-center"><div class="col-lg-7"><div class="card">
<div class="card-header" style="background:<?=$action==='add'?'#198754':'#fd7e14'?>;color:#fff;"><?=$title?></div>
<div class="card-body p-4"><form method="POST">
<div class="row g-3">
  <div class="col-md-4"><label class="form-label fw-semibold">Application ID *</label>
    <input name="application_id" class="form-control" value="<?=htmlspecialchars($ap['application_id']??'')?>" <?=$action==='edit'?'readonly':''?> required/></div>
  <div class="col-md-4"><label class="form-label fw-semibold">Date *</label>
    <input name="application_date" type="date" class="form-control" value="<?=$ap['application_date']??date('Y-m-d')?>" required/></div>
  <div class="col-md-4"><label class="form-label fw-semibold">Status</label>
    <select name="status" class="form-select">
      <?php foreach(['Pending','Approved','Rejected'] as $s): ?>
      <option value="<?=$s?>" <?=($ap['status']??'')===$s?'selected':''?>><?=$s?></option>
      <?php endforeach; ?>
    </select></div>
  <div class="col-md-6"><label class="form-label fw-semibold">Adopter</label>
    <select name="adopter_id" class="form-select">
    <?php foreach($adopters as $a): ?>
    <option value="<?=$a['adopter_id']?>" <?=($ap['adopter_id']??'')===$a['adopter_id']?'selected':''?>><?=htmlspecialchars($a['adopter_id'].' — '.$a['full_name'])?></option>
    <?php endforeach; ?>
    </select></div>
  <div class="col-md-6"><label class="form-label fw-semibold">Pet</label>
    <select name="pet_id" class="form-select">
    <?php foreach($pets as $p): ?>
    <option value="<?=$p['pet_id']?>" <?=($ap['pet_id']??'')===$p['pet_id']?'selected':''?>><?=htmlspecialchars($p['pet_id'].' — '.$p['name'].' ('.$p['adoption_status'].')')?></option>
    <?php endforeach; ?>
    </select></div>
  <div class="col-12"><label class="form-label fw-semibold">Notes</label>
    <textarea name="notes" class="form-control" rows="2"><?=htmlspecialchars($ap['notes']??'')?></textarea></div>
</div>
<div class="alert alert-info mt-3 mb-0" style="font-size:.85rem;">
  <i class="bi bi-lightning-fill me-2"></i><strong>Trigger note:</strong>
  Setting status to <strong>Approved</strong> fires <code>trg_approval_status</code>, which automatically sets the pet's <code>adoption_status = 'Adopted'</code> in the Pets table.<br/>
  Setting status to <strong>any value</strong> on INSERT fires <code>trg_log_application</code>, which writes to <code>Application_Audit</code>.
</div>
<div class="sql-box my-3">-- INSERT/UPDATE Adoption_Applications + triggers auto-fire</div>
<div class="d-flex gap-3 mt-2">
  <button class="btn <?=$action==='add'?'btn-create':'btn-update'?> flex-fill py-2">Save</button>
  <a href="applications.php" class="btn btn-outline-secondary flex-fill py-2">Cancel</a>
</div>
</form></div></div></div></div>
<?php require 'footer.php'; exit; }

// LIST
$res=pg_query($conn,"SELECT aa.*, p.name AS pet_name, ad.first_name||' '||ad.last_name AS adopter_name
FROM Adoption_Applications aa
JOIN Pets p ON aa.pet_id=p.pet_id
JOIN Adopters ad ON aa.adopter_id=ad.adopter_id
ORDER BY aa.application_date DESC");
$rows=pg_fetch_all($res)?:[];
require 'header.php';
?>
<div class="page-header"><h4><i class="bi bi-file-earmark-text me-2"></i>Adoption Applications — CRUD</h4>
<small>Weak entity connecting Adopters and Pets &nbsp;|&nbsp; ⚡ Triggers: trg_approval_status + trg_log_application</small></div>
<div class="mb-3"><a href="applications.php?action=add" class="btn btn-create"><i class="bi bi-plus-circle me-2"></i>New Application</a>
<a href="audit.php" class="btn btn-outline-info ms-2"><i class="bi bi-journal-text me-2"></i>View Audit Log</a></div>
<div class="card"><div class="card-header d-flex justify-content-between" style="background:#1a3a5c;color:#fff;">
  <span><i class="bi bi-table me-2"></i>Adoption_Applications Table</span>
  <span class="badge bg-light text-dark"><?=count($rows)?> record(s)</span>
</div><div class="card-body p-0"><div class="table-responsive">
<table class="table table-hover table-bordered mb-0"><thead><tr>
  <th>App ID</th><th>Date</th><th>Pet</th><th>Adopter</th><th>Status</th><th>Notes</th><th class="text-center">Actions</th>
</tr></thead><tbody>
<?php foreach($rows as $r):
  $sc=['Pending'=>'warning','Approved'=>'success','Rejected'=>'danger'][$r['status']]??'secondary'; ?>
<tr>
  <td><code><?=htmlspecialchars($r['application_id'])?></code></td>
  <td><?=$r['application_date']?></td>
  <td><?=htmlspecialchars($r['pet_name'])?> <small class="text-muted">(<?=$r['pet_id']?>)</small></td>
  <td><?=htmlspecialchars($r['adopter_name'])?></td>
  <td><span class="badge bg-<?=$sc?>"><?=$r['status']?></span></td>
  <td><small><?=htmlspecialchars(substr($r['notes']??'—',0,40))?></small></td>
  <td class="text-center text-nowrap">
    <a href="applications.php?action=edit&id=<?=urlencode($r['application_id'])?>" class="btn btn-update btn-sm me-1"><i class="bi bi-pencil-square me-1"></i>Edit</a>
    <a href="applications.php?action=delete&id=<?=urlencode($r['application_id'])?>" class="btn btn-delete btn-sm"><i class="bi bi-trash3 me-1"></i>Del</a>
  </td>
</tr>
<?php endforeach; ?>
</tbody></table></div></div></div>
<?php pg_close($conn); require 'footer.php'; ?>
