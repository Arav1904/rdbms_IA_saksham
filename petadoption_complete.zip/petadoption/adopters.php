<?php
session_start(); require 'db.php'; $conn = getDB();
$action = $_GET['action'] ?? 'list';

if ($action==='delete' && isset($_GET['id'])) {
    $id = esc($conn,$_GET['id']);
    $r  = pg_query($conn,"SELECT first_name||' '||last_name AS n FROM Adopters WHERE adopter_id='$id'");
    $name = pg_fetch_row($r)[0]??$id;
    if ($_SERVER['REQUEST_METHOD']==='POST') {
        pg_query($conn,"DELETE FROM Adopters WHERE adopter_id='$id'");
        $_SESSION['msg']="Adopter '<strong>{$name}</strong>' deleted."; $_SESSION['msg_type']='success';
        header('Location: adopters.php'); exit;
    }
    require 'header.php';
    $rd = pg_query($conn,"SELECT * FROM Adopters WHERE adopter_id='$id'"); $p=pg_fetch_assoc($rd);
    echo "<div class='page-header'><h4><i class='bi bi-trash3-fill me-2'></i>DELETE — Confirm Adopter Deletion</h4></div>";
    echo "<div class='row justify-content-center'><div class='col-lg-5'><div class='card border-danger'>";
    echo "<div class='card-header bg-danger text-white'>Confirm Delete — ".htmlspecialchars($name)."</div><div class='card-body'>";
    echo "<div class='alert alert-warning'>Deleting this adopter will also remove all their applications, references, and donations (ON DELETE CASCADE).</div>";
    echo "<table class='table table-bordered mb-3'>";
    foreach($p as $k=>$v) echo "<tr><th class='table-secondary' width='40%'>{$k}</th><td>".htmlspecialchars($v??'—')."</td></tr>";
    echo "</table><div class='sql-box mb-3'>DELETE FROM Adopters WHERE adopter_id = '{$id}';</div>";
    echo "<div class='d-flex gap-3'><form method='POST' class='flex-fill'><button class='btn btn-delete w-100 py-2'><i class='bi bi-trash3-fill me-2'></i>Yes, Delete</button></form>";
    echo "<a href='adopters.php' class='btn btn-outline-secondary flex-fill py-2'><i class='bi bi-x-circle me-2'></i>Cancel</a></div></div></div></div></div>";
    require 'footer.php'; exit;
}

if ($action==='add' || $action==='edit') {
    $ad=[]; $indiv=[]; $org=[];
    if ($action==='edit' && isset($_GET['id'])) {
        $id=esc($conn,$_GET['id']);
        $r=pg_query($conn,"SELECT * FROM Adopters WHERE adopter_id='$id'"); $ad=pg_fetch_assoc($r)?:[];
        $ri=pg_query($conn,"SELECT * FROM Individual WHERE adopter_id='$id'"); $indiv=pg_fetch_assoc($ri)?:[];
        $ro=pg_query($conn,"SELECT * FROM Organization WHERE adopter_id='$id'"); $org=pg_fetch_assoc($ro)?:[];
    }
    if ($_SERVER['REQUEST_METHOD']==='POST') {
        $aid=esc($conn,$_POST['adopter_id']); $fn=esc($conn,$_POST['first_name']); $ln=esc($conn,$_POST['last_name']);
        $em=esc($conn,$_POST['email']); $ph=esc($conn,$_POST['phone']); $addr=esc($conn,$_POST['address']);
        $dob=esc($conn,$_POST['dob']); $idp=esc($conn,$_POST['id_proof']);
        if ($action==='add') {
            pg_query($conn,"INSERT INTO Adopters VALUES ('$aid','$fn','$ln','$em','$ph','$addr','$dob','$idp') ON CONFLICT DO NOTHING");
            if (isset($_POST['is_individual'])) { $occ=esc($conn,$_POST['occupation']); pg_query($conn,"INSERT INTO Individual VALUES ('$aid','$occ') ON CONFLICT DO NOTHING"); }
            if (isset($_POST['is_org'])) { $reg=esc($conn,$_POST['org_reg_no']); pg_query($conn,"INSERT INTO Organization VALUES ('$aid','$reg') ON CONFLICT DO NOTHING"); }
        } else {
            $before_r=pg_query($conn,"SELECT * FROM Adopters WHERE adopter_id='$aid'"); $before=pg_fetch_assoc($before_r);
            pg_query($conn,"UPDATE Adopters SET first_name='$fn',last_name='$ln',email='$em',phone='$ph',address='$addr',dob='$dob',id_proof='$idp' WHERE adopter_id='$aid'");
            $after_r=pg_query($conn,"SELECT * FROM Adopters WHERE adopter_id='$aid'"); $after=pg_fetch_assoc($after_r);
            $_SESSION['before']=$before; $_SESSION['after']=$after;
            $_SESSION['sql']="UPDATE Adopters SET first_name='$fn', last_name='$ln', phone='$ph', email='$em'\nWHERE adopter_id = '$aid';";
            header('Location: update_result.php'); exit;
        }
        $_SESSION['msg']="Adopter saved successfully."; $_SESSION['msg_type']='success';
        header('Location: adopters.php'); exit;
    }
    require 'header.php';
    $title=$action==='add'?'CREATE — Add Adopter':'UPDATE — Edit Adopter';
?>
<div class="page-header"><h4><?= $title ?></h4><small>Includes Individual/Organization subclass assignment (EER overlapping specialization)</small></div>
<div class="row justify-content-center"><div class="col-lg-7"><div class="card">
<div class="card-header" style="background:<?=$action==='add'?'#198754':'#fd7e14'?>;color:#fff;"><?=$title?></div>
<div class="card-body p-4"><form method="POST">
<div class="row g-3">
  <div class="col-md-4"><label class="form-label fw-semibold">Adopter ID *</label>
    <input name="adopter_id" class="form-control" value="<?=htmlspecialchars($ad['adopter_id']??'')?>" <?=$action==='edit'?'readonly':''?> required/></div>
  <div class="col-md-4"><label class="form-label fw-semibold">First Name *</label>
    <input name="first_name" class="form-control" value="<?=htmlspecialchars($ad['first_name']??'')?>" required/></div>
  <div class="col-md-4"><label class="form-label fw-semibold">Last Name *</label>
    <input name="last_name" class="form-control" value="<?=htmlspecialchars($ad['last_name']??'')?>" required/></div>
  <div class="col-md-6"><label class="form-label fw-semibold">Email</label>
    <input name="email" type="email" class="form-control" value="<?=htmlspecialchars($ad['email']??'')?>"/></div>
  <div class="col-md-6"><label class="form-label fw-semibold">Phone *</label>
    <input name="phone" class="form-control" value="<?=htmlspecialchars($ad['phone']??'')?>" required/></div>
  <div class="col-12"><label class="form-label fw-semibold">Address</label>
    <input name="address" class="form-control" value="<?=htmlspecialchars($ad['address']??'')?>"/></div>
  <div class="col-md-6"><label class="form-label fw-semibold">Date of Birth</label>
    <input name="dob" type="date" class="form-control" value="<?=$ad['dob']??''?>"/></div>
  <div class="col-md-6"><label class="form-label fw-semibold">ID Proof Reference</label>
    <input name="id_proof" class="form-control" value="<?=htmlspecialchars($ad['id_proof']??'')?>"/></div>
  <?php if($action==='add'): ?>
  <div class="col-12"><div class="card p-3" style="background:#f0f4f8;">
    <p class="fw-bold mb-2"><i class="bi bi-diagram-2 me-2"></i>EER Subclass Assignment (overlapping — can select both)</p>
    <div class="form-check mb-2"><input type="checkbox" name="is_individual" class="form-check-input" id="chkI" onchange="toggleI()"/>
      <label class="form-check-label fw-semibold" for="chkI">Individual</label></div>
    <div id="indivFields" class="ms-4 mb-3 d-none">
      <input name="occupation" class="form-control" placeholder="Occupation"/></div>
    <div class="form-check mb-2"><input type="checkbox" name="is_org" class="form-check-input" id="chkO" onchange="toggleO()"/>
      <label class="form-check-label fw-semibold" for="chkO">Organization</label></div>
    <div id="orgFields" class="ms-4 d-none">
      <input name="org_reg_no" class="form-control" placeholder="Organization Reg. No."/></div>
  </div></div>
  <?php endif; ?>
</div>
<div class="sql-box my-3"><?=$action==='add'?"INSERT INTO Adopters (adopter_id, first_name, last_name, email, phone, ...)\nVALUES (...);":"UPDATE Adopters SET first_name=..., last_name=..., phone=...\nWHERE adopter_id = '".htmlspecialchars($ad['adopter_id']??'')."';"?></div>
<div class="d-flex gap-3">
  <button class="btn <?=$action==='add'?'btn-create':'btn-update'?> flex-fill py-2">Save</button>
  <a href="adopters.php" class="btn btn-outline-secondary flex-fill py-2">Cancel</a>
</div>
</form></div></div></div></div>
<script>
function toggleI(){document.getElementById('indivFields').classList.toggle('d-none',!document.getElementById('chkI').checked);}
function toggleO(){document.getElementById('orgFields').classList.toggle('d-none',!document.getElementById('chkO').checked);}
</script>
<?php require 'footer.php'; exit; }

// LIST
$res = pg_query($conn,"SELECT a.*,
    CASE WHEN i.adopter_id IS NOT NULL AND o.adopter_id IS NOT NULL THEN 'Individual + Org'
         WHEN i.adopter_id IS NOT NULL THEN 'Individual'
         WHEN o.adopter_id IS NOT NULL THEN 'Organization' ELSE '—' END AS subclass,
    (SELECT COUNT(*) FROM Adoption_Applications ap WHERE ap.adopter_id=a.adopter_id) AS apps,
    (SELECT COUNT(*) FROM References_Table r WHERE r.adopter_id=a.adopter_id) AS refs
FROM Adopters a
LEFT JOIN Individual i ON a.adopter_id=i.adopter_id
LEFT JOIN Organization o ON a.adopter_id=o.adopter_id
ORDER BY a.adopter_id");
$rows=pg_fetch_all($res)?:[];
require 'header.php';
?>
<div class="page-header"><h4><i class="bi bi-people me-2"></i>Adopters — CRUD Operations</h4>
<small>Overlapping specialization: Individual / Organization &nbsp;|&nbsp; Weak entity: References_Table</small></div>
<div class="mb-3"><a href="adopters.php?action=add" class="btn btn-create"><i class="bi bi-plus-circle me-2"></i>Add Adopter</a></div>
<div class="card"><div class="card-header d-flex justify-content-between" style="background:#1a3a5c;color:#fff;">
  <span><i class="bi bi-table me-2"></i>Adopters Table</span>
  <span class="badge bg-light text-dark"><?=count($rows)?> record(s)</span>
</div><div class="card-body p-0"><div class="table-responsive">
<table class="table table-hover table-bordered mb-0"><thead><tr>
  <th>ID</th><th>Name</th><th>Phone</th><th>Email</th><th>Subclass</th><th>Apps</th><th>Refs</th><th class="text-center">Actions</th>
</tr></thead><tbody>
<?php foreach($rows as $r): ?>
<tr>
  <td><code><?=htmlspecialchars($r['adopter_id'])?></code></td>
  <td><strong><?=htmlspecialchars($r['first_name'].' '.$r['last_name'])?></strong></td>
  <td><?=htmlspecialchars($r['phone'])?></td>
  <td><?=htmlspecialchars($r['email']??'—')?></td>
  <td><span class="badge bg-info text-dark"><?=$r['subclass']?></span></td>
  <td><span class="badge bg-primary"><?=$r['apps']?></span></td>
  <td><span class="badge bg-secondary"><?=$r['refs']?></span></td>
  <td class="text-center text-nowrap">
    <a href="adopters.php?action=edit&id=<?=urlencode($r['adopter_id'])?>" class="btn btn-update btn-sm me-1"><i class="bi bi-pencil-square me-1"></i>Edit</a>
    <a href="adopters.php?action=delete&id=<?=urlencode($r['adopter_id'])?>" class="btn btn-delete btn-sm"><i class="bi bi-trash3 me-1"></i>Del</a>
  </td>
</tr>
<?php endforeach; ?>
</tbody></table></div></div></div>
<?php pg_close($conn); require 'footer.php'; ?>
