<?php
// ─── Database Connection — PostgreSQL via pgAdmin ───────────────────────────
// XAMPP uses PHP. We connect to PostgreSQL (pgAdmin) using pg_connect().
// Make sure the PostgreSQL extension is enabled in php.ini:
//   uncomment: extension=pgsql   and   extension=pdo_pgsql

define('DB_HOST',     'localhost');
define('DB_PORT',     '5432');
define('DB_NAME',     'pet_adoption_db');
define('DB_USER',     'postgres');
define('DB_PASS',     'your_password');   // ← change to your pgAdmin password

function getDB() {
    $connStr = "host=" . DB_HOST .
               " port=" . DB_PORT .
               " dbname=" . DB_NAME .
               " user=" . DB_USER .
               " password=" . DB_PASS;
    $conn = pg_connect($connStr);
    if (!$conn) {
        die("<div class='alert alert-danger m-4'>
             <strong>Database connection failed.</strong><br/>
             Check your PostgreSQL password in db.php and ensure PostgreSQL is running.
             </div>");
    }
    return $conn;
}

// Safe escape helper
function esc($conn, $val) {
    return pg_escape_string($conn, trim($val));
}
?>
