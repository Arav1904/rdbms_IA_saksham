<?php
session_start();
require 'db.php';
$conn = getDB();
$tables = [
  ['Pets','bi-paw','btn-read','pets.php'],
  ['Adopters','bi-people','btn-create','adopters.php'],
  ['Adoption_Applications','bi-file-earmark-check','btn-update','applications.php'],
  ['Appointments','bi-calendar-check','btn-read','appointments.php'],
  ['Pet_Care_Providers','bi-hospital','btn-create','providers.php'],
  ['Medical_Records','bi-clipboard2-pulse','btn-update','medical.php'],
  ['Staff','bi-person-badge','btn-read','staff.php'],
  ['Donation','bi-cash-coin','btn-create','donations.php'],
  ['Training_Programs','bi-trophy','btn-update','training.php'],
];
require 'header.php';
?>

<div class="page-header">
  <h4><i class="bi bi-house-heart me-2"></i>Dashboard — Pet Adoption & Care System</h4>
  <small>XAMPP PHP + pgAdmin PostgreSQL &nbsp;|&nbsp; Full EER Schema — 22 Tables, 4 Specializations, 11 Relationships</small>
</div>

<!-- Stats row -->
<div class="row g-3 mb-4">
<?php
$stats = [
  ['Available Pets',   "SELECT COUNT(*) FROM Pets WHERE adoption_status='Available'",   '#198754','bi-heart'],
  ['Adopted Pets',     "SELECT COUNT(*) FROM Pets WHERE adoption_status='Adopted'",     '#6c757d','bi-check-circle'],
  ['Pending Apps',     "SELECT COUNT(*) FROM Adoption_Applications WHERE status='Pending'", '#fd7e14','bi-hourglass-split'],
  ['Total Adopters',   "SELECT COUNT(*) FROM Adopters",                                 '#0d6efd','bi-people'],
  ['Appointments',     "SELECT COUNT(*) FROM Appointments",                             '#6f42c1','bi-calendar'],
  ['Medical Records',  "SELECT COUNT(*) FROM Medical_Records",                          '#d63384','bi-clipboard2-pulse'],
  ['Staff Members',    "SELECT COUNT(*) FROM Staff",                                    '#20c997','bi-person-badge'],
  ['Total Donations',  "SELECT COALESCE(SUM(amount),0) FROM Donation",                 '#ffc107','bi-cash'],
];
foreach ($stats as [$label,$sql,$col,$icon]) {
    $res = pg_query($conn, $sql);
    $val = pg_fetch_row($res)[0];
    if (str_contains($label,'Donation')) $val = '₹'.number_format($val,0);
    echo "<div class='col-md-3 col-6'>
          <div class='card text-white' style='background:{$col};border-radius:12px;'>
            <div class='card-body d-flex align-items-center gap-3'>
              <i class='bi {$icon}' style='font-size:2rem;opacity:.8;'></i>
              <div><div style='font-size:1.6rem;font-weight:700;'>{$val}</div>
                   <div style='font-size:.85rem;opacity:.9;'>{$label}</div></div>
            </div>
          </div></div>";
}
?>
</div>

<!-- Quick CRUD Cards for each entity -->
<h5 class="mb-3 fw-bold" style="color:#1a3a5c;">
  <i class="bi bi-table me-2"></i>All Entities — Quick Access
</h5>
<div class="row g-3 mb-4">
<?php
foreach ($tables as [$tbl,$icon,$btnClass,$link]) {
    $res = pg_query($conn, "SELECT COUNT(*) FROM {$tbl}");
    $cnt = pg_fetch_row($res)[0];
    echo "<div class='col-md-4'>
          <div class='card'>
            <div class='card-body d-flex justify-content-between align-items-center'>
              <div>
                <div class='fw-bold' style='color:#1a3a5c;'>
                  <i class='bi {$icon} me-2'></i>{$tbl}
                </div>
                <div class='text-muted' style='font-size:.85rem;'>{$cnt} record(s)</div>
              </div>
              <a href='{$link}' class='btn {$btnClass} btn-sm px-3'>
                <i class='bi bi-arrow-right'></i> Manage
              </a>
            </div>
          </div></div>";
}
?>
</div>

<!-- Relationship Summary -->
<div class="card mb-4">
  <div class="card-header" style="background:#1a3a5c;color:#fff;">
    <i class="bi bi-diagram-3 me-2"></i>EER Relationships Implemented in This Database
  </div>
  <div class="card-body p-0">
    <div class="table-responsive">
    <table class="table table-hover table-bordered mb-0">
      <thead><tr>
        <th>Relationship</th><th>Entities</th><th>Type</th><th>EER Feature</th>
      </tr></thead>
      <tbody>
        <?php
        $rels = [
          ['HOUSES',          'Shelter → Pets',                       '1 : N',  'Regular relationship'],
          ['RECEIVES',        'Pets → Adoption_Applications',          '1 : N',  'Identifying relationship (double diamond)'],
          ['SUBMITS',         'Adopters → Adoption_Applications',      '1 : N',  'Total participation on Adopters side'],
          ['SCHEDULES',       'Pets → Appointments',                   '1 : N',  'Weak entity (Appointments)'],
          ['HANDLES',         'Pet_Care_Providers → Appointments',     '1 : N',  'Regular relationship'],
          ['HAS',             'Pets → Medical_Records',                '1 : N',  'Identifying (weak entity Medical_Records)'],
          ['CREATES',         'Veterinarian → Medical_Records',        '1 : N',  'Subclass relationship'],
          ['HAS (Ref)',        'Adopters → References_Table',           '1 : N',  'Identifying relationship (weak entity References)'],
          ['CARES FOR',       'Staff ↔ Pets',                          'M : N',  'Many-to-Many → Staff_Pet junction table'],
          ['MAKES',           'Adopters → Donation',                   '1 : N',  'Regular relationship'],
          ['ENROLLS IN',      'Dog ↔ Training_Programs',               'M : N',  'M:N on subclass → Dog_Training junction table'],
          ['Is-A (d)',        'Pets → Dog / Cat / Other_Animal',        'Disjoint','EER Specialization'],
          ['Is-A (o)',        'Adopters → Individual / Organization',   'Overlapping','EER Specialization'],
          ['Is-A (d)',        'Pet_Care_Providers → Vet / Groomer',     'Disjoint','EER Specialization'],
          ['Is-A (d)',        'Staff → Volunteer / Employee',           'Disjoint','EER Specialization'],
        ];
        foreach ($rels as $i=>[$r,$e,$c,$f]) {
            $bg = $i%2==0 ? '' : 'style="background:#f8f9fa;"';
            echo "<tr {$bg}><td><strong>{$r}</strong></td><td>{$e}</td>
                  <td><span class='badge bg-primary'>{$c}</span></td><td>{$f}</td></tr>";
        }
        ?>
      </tbody>
    </table>
    </div>
  </div>
</div>

<?php pg_close($conn); require 'footer.php'; ?>
