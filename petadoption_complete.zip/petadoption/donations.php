<?php
// Generic helper — builds a simple list+add+delete CRUD page for supporting tables
session_start(); require 'db.php'; $conn = getDB();

$page    = basename($_SERVER['PHP_SELF'], '.php');
$configs = [
  'providers' => [
    'title'   => 'Pet Care Providers',
    'icon'    => 'bi-hospital',
    'table'   => 'Pet_Care_Providers',
    'pk'      => 'provider_id',
    'cols'    => ['provider_id','name','qualification','phone','email','visiting_fee'],
    'labels'  => ['Provider ID','Name','Qualification','Phone','Email','Visiting Fee'],
    'types'   => ['text','text','text','text','email','number'],
    'note'    => 'Disjoint specialization: Veterinarian / Groomer subclasses stored separately',
  ],
  'staff' => [
    'title'   => 'Staff',
    'icon'    => 'bi-person-badge',
    'table'   => 'Staff',
    'pk'      => 'staff_id',
    'cols'    => ['staff_id','name','role','shift'],
    'labels'  => ['Staff ID','Name','Role','Shift'],
    'types'   => ['text','text','text','select:Morning|Evening|Night'],
    'note'    => 'Disjoint specialization: Volunteer / Employee. M:N with Pets via Staff_Pet.',
  ],
  'donations' => [
    'title'   => 'Donations',
    'icon'    => 'bi-cash-coin',
    'table'   => 'Donation',
    'pk'      => 'donation_id',
    'cols'    => ['donation_id','amount','donation_date','purpose','payment_mode','adopter_id'],
    'labels'  => ['Donation ID','Amount','Date','Purpose','Payment Mode','Adopter ID'],
    'types'   => ['text','number','date','text','select:Cash|UPI|Bank Transfer|Cheque','text'],
    'note'    => '1:N with Adopters — one adopter can make many donations',
  ],
  'medical' => [
    'title'   => 'Medical Records',
    'icon'    => 'bi-clipboard2-pulse',
    'table'   => 'Medical_Records',
    'pk'      => 'record_id',
    'cols'    => ['record_date','diagnosis','treatment','follow_up_date','cost','pet_id','provider_id'],
    'labels'  => ['Date','Diagnosis','Treatment','Follow-up Date','Cost','Pet ID','Provider ID (Vet)'],
    'types'   => ['date','text','text','date','number','text','text'],
    'note'    => 'Weak entity — depends on Pets. Linked to Veterinarian subclass only.',
  ],
  'training' => [
    'title'   => 'Training Programs',
    'icon'    => 'bi-trophy',
    'table'   => 'Training_Programs',
    'pk'      => 'program_id',
    'cols'    => ['program_id','program_name','duration_weeks','trainer_name'],
    'labels'  => ['Program ID','Program Name','Duration (weeks)','Trainer Name'],
    'types'   => ['text','text','number','text'],
    'note'    => 'M:N with Dog subclass via Dog_Training junction table.',
  ],
];

$cfg = $configs[$page] ?? null;
if (!$cfg) { echo "Page not configured."; exit; }

// ── DELETE ───────────────────────────────────────────────────────────────────
if (isset($_GET['action']) && $_GET['action']==='delete' && isset($_GET['id'])) {
    $id = esc($conn,$_GET['id']);
    if ($_SERVER['REQUEST_METHOD']==='POST') {
        pg_query($conn,"DELETE FROM {$cfg['table']} WHERE {$cfg['pk']}='$id'");
        $_SESSION['msg']="Record deleted."; $_SESSION['msg_type']='success';
        header("Location: {$page}.php"); exit;
    }
    require 'header.php';
    $r=pg_query($conn,"SELECT * FROM {$cfg['table']} WHERE {$cfg['pk']}='$id'"); $row=pg_fetch_assoc($r);
    echo "<div class='page-header'><h4>DELETE — Confirm Deletion ({$cfg['title']})</h4></div>";
    echo "<div class='row justify-content-center'><div class='col-lg-5'><div class='card border-danger'>";
    echo "<div class='card-header bg-danger text-white'>Confirm Delete</div><div class='card-body'>";
    foreach($row as $k=>$v) echo "<div><strong>{$k}:</strong> ".htmlspecialchars($v??'—')."</div>";
    echo "<div class='sql-box my-3'>DELETE FROM {$cfg['table']} WHERE {$cfg['pk']} = '$id';</div>";
    echo "<div class='d-flex gap-3 mt-2'><form method='POST' class='flex-fill'><button class='btn btn-delete w-100 py-2'>Yes, Delete</button></form>";
    echo "<a href='{$page}.php' class='btn btn-outline-secondary flex-fill py-2'>Cancel</a></div>";
    echo "</div></div></div></div>";
    require 'footer.php'; exit;
}

// ── ADD ──────────────────────────────────────────────────────────────────────
if (isset($_GET['action']) && $_GET['action']==='add') {
    if ($_SERVER['REQUEST_METHOD']==='POST') {
        $vals = []; $cols2 = [];
        foreach ($cfg['cols'] as $i=>$col) {
            if ($col==='record_id') continue; // serial
            $cols2[] = $col;
            $v = esc($conn,$_POST[$col]??'');
            $vals[] = "'{$v}'";
        }
        $clist = implode(',',$cols2); $vlist = implode(',',$vals);
        $q = pg_query($conn,"INSERT INTO {$cfg['table']} ({$clist}) VALUES ({$vlist})");
        if(!$q) { $_SESSION['msg']="Error: ".pg_last_error($conn); $_SESSION['msg_type']='danger'; }
        else { $_SESSION['msg']="Record added to {$cfg['title']}."; $_SESSION['msg_type']='success'; }
        header("Location: {$page}.php"); exit;
    }
    require 'header.php';
    echo "<div class='page-header'><h4><i class='bi bi-plus-circle-fill me-2'></i>CREATE — Add {$cfg['title']}</h4><small>{$cfg['note']}</small></div>";
    echo "<div class='row justify-content-center'><div class='col-lg-7'><div class='card'>";
    echo "<div class='card-header' style='background:#198754;color:#fff;'>Add New Record</div><div class='card-body p-4'>";
    echo "<form method='POST'><div class='row g-3'>";
    foreach ($cfg['cols'] as $i=>$col) {
        if ($col==='record_id') continue;
        $lbl = $cfg['labels'][$i];
        $typ = $cfg['types'][$i]??'text';
        echo "<div class='col-md-6'><label class='form-label fw-semibold'>{$lbl}</label>";
        if (str_starts_with($typ,'select:')) {
            $opts = explode('|', substr($typ,7));
            echo "<select name='{$col}' class='form-select'>";
            foreach($opts as $o) echo "<option>{$o}</option>";
            echo "</select>";
        } else {
            echo "<input name='{$col}' type='{$typ}' class='form-control' step='0.01'/>";
        }
        echo "</div>";
    }
    echo "</div><div class='sql-box my-3'>INSERT INTO {$cfg['table']} (...) VALUES (...);</div>";
    echo "<div class='d-flex gap-3 mt-2'><button class='btn btn-create flex-fill py-2'>Save</button><a href='{$page}.php' class='btn btn-outline-secondary flex-fill py-2'>Cancel</a></div>";
    echo "</form></div></div></div></div>";
    require 'footer.php'; exit;
}

// ── LIST ─────────────────────────────────────────────────────────────────────
$res  = pg_query($conn,"SELECT * FROM {$cfg['table']} ORDER BY 1");
$rows = pg_fetch_all($res)?:[];
require 'header.php';
?>
<div class="page-header">
  <h4><i class="bi <?= $cfg['icon'] ?> me-2"></i><?= $cfg['title'] ?> — CRUD</h4>
  <small><?= $cfg['note'] ?></small>
</div>
<div class="mb-3">
  <a href="<?=$page?>.php?action=add" class="btn btn-create">
    <i class="bi bi-plus-circle me-2"></i>Add <?= $cfg['title'] ?>
  </a>
</div>
<div class="card">
  <div class="card-header d-flex justify-content-between" style="background:#1a3a5c;color:#fff;">
    <span><i class="bi bi-table me-2"></i><?= $cfg['table'] ?></span>
    <span class="badge bg-light text-dark"><?=count($rows)?> record(s)</span>
  </div>
  <div class="card-body p-0"><div class="table-responsive">
  <table class="table table-hover table-bordered mb-0">
    <thead><tr>
      <?php if($rows) foreach(array_keys($rows[0]) as $col) echo "<th>{$col}</th>"; ?>
      <th class="text-center">Actions</th>
    </tr></thead>
    <tbody>
    <?php foreach($rows as $r): ?>
    <tr>
      <?php foreach($r as $v) echo "<td>".htmlspecialchars($v??'—')."</td>"; ?>
      <td class="text-center text-nowrap">
        <a href="<?=$page?>.php?action=delete&id=<?=urlencode($r[$cfg['pk']]??$r['record_id']??'')?>"
           class="btn btn-delete btn-sm"><i class="bi bi-trash3 me-1"></i>Delete</a>
      </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div></div>
</div>
<?php
// Show subclass tables if relevant
if ($page==='providers') {
    $vets  = pg_fetch_all(pg_query($conn,"SELECT v.*, pcp.name FROM Veterinarian v JOIN Pet_Care_Providers pcp ON v.provider_id=pcp.provider_id"))?:[];
    $grms  = pg_fetch_all(pg_query($conn,"SELECT g.*, pcp.name FROM Groomer g JOIN Pet_Care_Providers pcp ON g.provider_id=pcp.provider_id"))?:[];
    echo "<div class='row g-3 mt-2'>";
    foreach([['Veterinarian subclass',$vets,'#1F3864'],['Groomer subclass',$grms,'#375623']] as [$t,$data,$c]) {
        echo "<div class='col-md-6'><div class='card'><div class='card-header' style='background:{$c};color:#fff;'>{$t}</div>";
        echo "<div class='card-body p-0'><table class='table table-sm table-bordered mb-0'><thead><tr>";
        if($data) foreach(array_keys($data[0]) as $col) echo "<th>{$col}</th>";
        echo "</tr></thead><tbody>";
        foreach($data as $r) { echo "<tr>"; foreach($r as $v) echo "<td>".htmlspecialchars($v??'—')."</td>"; echo "</tr>"; }
        echo "</tbody></table></div></div></div>";
    }
    echo "</div>";
}
if ($page==='staff') {
    $vols = pg_fetch_all(pg_query($conn,"SELECT v.*, s.name FROM Volunteer v JOIN Staff s ON v.staff_id=s.staff_id"))?:[];
    $emps = pg_fetch_all(pg_query($conn,"SELECT e.*, s.name FROM Employee e JOIN Staff s ON e.staff_id=s.staff_id"))?:[];
    $sp   = pg_fetch_all(pg_query($conn,"SELECT sp.*, s.name AS staff_name, p.name AS pet_name FROM Staff_Pet sp JOIN Staff s ON sp.staff_id=s.staff_id JOIN Pets p ON sp.pet_id=p.pet_id"))?:[];
    echo "<div class='row g-3 mt-2'>";
    foreach([['Volunteer subclass',$vols,'#1F3864'],['Employee subclass',$emps,'#375623']] as [$t,$data,$c]) {
        echo "<div class='col-md-6'><div class='card'><div class='card-header' style='background:{$c};color:#fff;'>{$t}</div>";
        echo "<div class='card-body p-0'><table class='table table-sm table-bordered mb-0'><thead><tr>";
        if($data) foreach(array_keys($data[0]) as $col) echo "<th>{$col}</th>";
        echo "</tr></thead><tbody>";
        foreach($data as $r) { echo "<tr>"; foreach($r as $v) echo "<td>".htmlspecialchars($v??'—')."</td>"; echo "</tr>"; }
        echo "</tbody></table></div></div></div>";
    }
    echo "</div>";
    echo "<div class='card mt-3'><div class='card-header' style='background:#6f42c1;color:#fff;'>Staff_Pet (M:N junction — Staff CARES FOR Pets)</div>";
    echo "<div class='card-body p-0'><table class='table table-sm table-bordered mb-0'><thead><tr><th>staff_id</th><th>Staff Name</th><th>pet_id</th><th>Pet Name</th></tr></thead><tbody>";
    foreach($sp as $r) echo "<tr><td><code>{$r['staff_id']}</code></td><td>".htmlspecialchars($r['staff_name'])."</td><td><code>{$r['pet_id']}</code></td><td>".htmlspecialchars($r['pet_name'])."</td></tr>";
    echo "</tbody></table></div></div>";
}
if ($page==='training') {
    $dt = pg_fetch_all(pg_query($conn,"SELECT dt.*, d.pet_id, p.name AS dog_name, t.program_name FROM Dog_Training dt JOIN Dog d ON dt.pet_id=d.pet_id JOIN Pets p ON d.pet_id=p.pet_id JOIN Training_Programs t ON dt.program_id=t.program_id"))?:[];
    echo "<div class='card mt-3'><div class='card-header' style='background:#6f42c1;color:#fff;'>Dog_Training (M:N junction — Dog ENROLLS IN Training_Programs)</div>";
    echo "<div class='card-body p-0'><table class='table table-sm table-bordered mb-0'><thead><tr><th>Dog</th><th>Program</th></tr></thead><tbody>";
    foreach($dt as $r) echo "<tr><td>{$r['dog_name']} ({$r['pet_id']})</td><td>".htmlspecialchars($r['program_name'])."</td></tr>";
    echo "</tbody></table></div></div>";
}
pg_close($conn); require 'footer.php';
?>
