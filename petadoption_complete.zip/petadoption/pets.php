<?php
session_start();
require 'db.php';
$conn = getDB();
$action = $_GET['action'] ?? 'list';

// ── DELETE ──────────────────────────────────────────────────────────────────
if ($action === 'delete' && isset($_GET['id'])) {
    $id = esc($conn, $_GET['id']);
    $res = pg_query($conn, "SELECT name FROM Pets WHERE pet_id='$id'");
    $name = pg_fetch_row($res)[0] ?? $id;
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        pg_query($conn, "DELETE FROM Pets WHERE pet_id='$id'");
        $_SESSION['msg']      = "<i class='bi bi-trash3-fill me-2'></i>Pet '<strong>{$name}</strong>' (ID: {$id}) deleted successfully.";
        $_SESSION['msg_type'] = 'success';
        header('Location: pets.php'); exit;
    }
    require 'header.php';
?>
<div class="page-header"><h4><i class="bi bi-trash3-fill me-2"></i>DELETE — Confirm Deletion</h4></div>
<div class="row justify-content-center"><div class="col-lg-5">
  <div class="card border-danger">
    <div class="card-header bg-danger text-white"><i class="bi bi-exclamation-triangle-fill me-2"></i>Confirm Delete</div>
    <div class="card-body">
      <div class="alert alert-warning"><i class="bi bi-exclamation-triangle me-2"></i>
        This will permanently delete pet <strong><?= htmlspecialchars($name) ?></strong> (<?= $id ?>) and all related records (appointments, medical records, applications) due to ON DELETE CASCADE.</div>
      <?php
        $r = pg_query($conn,"SELECT * FROM Pets WHERE pet_id='$id'");
        $p = pg_fetch_assoc($r);
      ?>
      <table class="table table-bordered mb-3">
        <?php foreach($p as $k=>$v): ?>
        <tr><th class="table-secondary" width="40%"><?= $k ?></th>
            <td><?= htmlspecialchars($v ?? '—') ?></td></tr>
        <?php endforeach; ?>
      </table>
      <div class="sql-box mb-3">DELETE FROM Pets WHERE pet_id = '<?= $id ?>';</div>
      <div class="d-flex gap-3">
        <form method="POST" class="flex-fill">
          <button class="btn btn-delete w-100 py-2"><i class="bi bi-trash3-fill me-2"></i>Yes, Delete</button>
        </form>
        <a href="pets.php" class="btn btn-outline-secondary flex-fill py-2"><i class="bi bi-x-circle me-2"></i>Cancel</a>
      </div>
    </div>
  </div>
</div></div>
<?php require 'footer.php'; exit; } // end delete

// ── ADD / EDIT FORM ──────────────────────────────────────────────────────────
if ($action === 'add' || $action === 'edit') {
    $pet = [];
    $dog = $cat = $other = [];
    if ($action === 'edit' && isset($_GET['id'])) {
        $id  = esc($conn, $_GET['id']);
        $r   = pg_query($conn,"SELECT * FROM Pets WHERE pet_id='$id'"); $pet = pg_fetch_assoc($r) ?: [];
        $rd  = pg_query($conn,"SELECT * FROM Dog WHERE pet_id='$id'");  $dog = pg_fetch_assoc($rd) ?: [];
        $rc  = pg_query($conn,"SELECT * FROM Cat WHERE pet_id='$id'");  $cat = pg_fetch_assoc($rc) ?: [];
        $ro  = pg_query($conn,"SELECT * FROM Other_Animal WHERE pet_id='$id'"); $other = pg_fetch_assoc($ro) ?: [];
    }
    // GET shelters for dropdown
    $sh = pg_query($conn,"SELECT shelter_id, shelter_name FROM Shelter ORDER BY shelter_name");

    // ── HANDLE FORM SUBMIT ───────────────────────────────────────────────────
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $pid    = esc($conn,$_POST['pet_id']);
        $name   = esc($conn,$_POST['name']);
        $breed  = esc($conn,$_POST['breed']);
        $age    = (int)$_POST['age'];
        $gender = esc($conn,$_POST['gender']);
        $wt     = (float)$_POST['weight_kg'];
        $idate  = esc($conn,$_POST['intake_date']);
        $status = esc($conn,$_POST['adoption_status']);
        $chip   = esc($conn,$_POST['microchip_id']);
        $vacc   = isset($_POST['is_vaccinated']) ? 'TRUE' : 'FALSE';
        $shelid = esc($conn,$_POST['shelter_id']);
        $species= esc($conn,$_POST['species']);

        if ($action === 'add') {
            $sql = "INSERT INTO Pets (pet_id,name,breed,age,gender,weight_kg,intake_date,
                    adoption_status,microchip_id,is_vaccinated,shelter_id)
                    VALUES ('$pid','$name','$breed',$age,'$gender',$wt,'$idate',
                    '$status','$chip',$vacc,'$shelid')";
            pg_query($conn,$sql);
            // Insert subclass
            if ($species==='Dog') {
                $sz = esc($conn,$_POST['size']??'Medium');
                $tr = isset($_POST['is_trained']) ? 'TRUE' : 'FALSE';
                pg_query($conn,"INSERT INTO Dog VALUES ('$pid','$sz',$tr) ON CONFLICT DO NOTHING");
            } elseif ($species==='Cat') {
                $ind = isset($_POST['is_indoor']) ? 'TRUE' : 'FALSE';
                $fl  = esc($conn,$_POST['fur_length']??'Short');
                pg_query($conn,"INSERT INTO Cat VALUES ('$pid',$ind,'$fl') ON CONFLICT DO NOTHING");
            } elseif ($species==='Other') {
                $spn = esc($conn,$_POST['species_name']??'');
                pg_query($conn,"INSERT INTO Other_Animal VALUES ('$pid','$spn') ON CONFLICT DO NOTHING");
            }
            $_SESSION['msg']="<i class='bi bi-plus-circle-fill me-2'></i>Pet '<strong>{$name}</strong>' added successfully!";
        } else {
            // capture BEFORE for display
            $rb = pg_query($conn,"SELECT * FROM Pets WHERE pet_id='$pid'");
            $before = pg_fetch_assoc($rb);
            $sql = "UPDATE Pets SET name='$name',breed='$breed',age=$age,gender='$gender',
                    weight_kg=$wt,intake_date='$idate',adoption_status='$status',
                    microchip_id='$chip',is_vaccinated=$vacc,shelter_id='$shelid'
                    WHERE pet_id='$pid'";
            pg_query($conn,$sql);
            $ra = pg_query($conn,"SELECT * FROM Pets WHERE pet_id='$pid'");
            $after = pg_fetch_assoc($ra);
            // store for before/after page
            $_SESSION['before'] = $before;
            $_SESSION['after']  = $after;
            $_SESSION['sql']    = "UPDATE Pets SET name='$name', breed='$breed', age=$age, gender='$gender',\n    adoption_status='$status', is_vaccinated=$vacc\nWHERE pet_id = '$pid';";
            header("Location: update_result.php"); exit;
        }
        $_SESSION['msg_type'] = 'success';
        header('Location: pets.php'); exit;
    }
    require 'header.php';
    $title = $action==='add' ? 'CREATE — Add New Pet' : 'UPDATE — Edit Pet';
    $btnCol = $action==='add' ? 'btn-create' : 'btn-update';
?>
<div class="page-header"><h4><i class="bi bi-<?= $action==='add'?'plus-circle-fill':'pencil-square' ?> me-2"></i><?= $title ?></h4></div>
<div class="row justify-content-center"><div class="col-lg-7">
<div class="card"><div class="card-header" style="background:<?= $action==='add'?'#198754':'#fd7e14' ?>;color:#fff;">
  <?= $title ?>
</div><div class="card-body p-4">
<form method="POST">
  <div class="row g-3">
    <div class="col-md-4">
      <label class="form-label fw-semibold">Pet ID *</label>
      <input name="pet_id" class="form-control" value="<?= htmlspecialchars($pet['pet_id']??'') ?>"
             <?= $action==='edit'?'readonly':'' ?> required maxlength="10" placeholder="e.g. P007"/>
    </div>
    <div class="col-md-8">
      <label class="form-label fw-semibold">Name *</label>
      <input name="name" class="form-control" value="<?= htmlspecialchars($pet['name']??'') ?>" required maxlength="50"/>
    </div>
    <div class="col-md-6">
      <label class="form-label fw-semibold">Breed</label>
      <input name="breed" class="form-control" value="<?= htmlspecialchars($pet['breed']??'') ?>"/>
    </div>
    <div class="col-md-3">
      <label class="form-label fw-semibold">Age (yrs) *</label>
      <input name="age" type="number" class="form-control" value="<?= $pet['age']??'' ?>" min="0" max="30" required/>
    </div>
    <div class="col-md-3">
      <label class="form-label fw-semibold">Weight (kg)</label>
      <input name="weight_kg" type="number" step="0.1" class="form-control" value="<?= $pet['weight_kg']??'' ?>"/>
    </div>
    <div class="col-md-4">
      <label class="form-label fw-semibold">Gender</label>
      <select name="gender" class="form-select">
        <option value="Male"   <?= ($pet['gender']??'')==='Male'  ?'selected':'' ?>>Male</option>
        <option value="Female" <?= ($pet['gender']??'')==='Female'?'selected':'' ?>>Female</option>
      </select>
    </div>
    <div class="col-md-4">
      <label class="form-label fw-semibold">Adoption Status</label>
      <select name="adoption_status" class="form-select">
        <?php foreach(['Available','Reserved','Adopted'] as $s): ?>
        <option value="<?=$s?>" <?= ($pet['adoption_status']??'')===$s?'selected':'' ?>><?=$s?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-4">
      <label class="form-label fw-semibold">Intake Date</label>
      <input name="intake_date" type="date" class="form-control" value="<?= $pet['intake_date']??date('Y-m-d') ?>"/>
    </div>
    <div class="col-md-6">
      <label class="form-label fw-semibold">Microchip ID</label>
      <input name="microchip_id" class="form-control" value="<?= htmlspecialchars($pet['microchip_id']??'') ?>"/>
    </div>
    <div class="col-md-6">
      <label class="form-label fw-semibold">Shelter</label>
      <select name="shelter_id" class="form-select">
        <?php pg_result_seek($sh,0); while($row=pg_fetch_assoc($sh)): ?>
        <option value="<?= $row['shelter_id'] ?>" <?= ($pet['shelter_id']??'')===$row['shelter_id']?'selected':'' ?>>
          <?= htmlspecialchars($row['shelter_name']) ?>
        </option>
        <?php endwhile; ?>
      </select>
    </div>
    <div class="col-12">
      <div class="form-check">
        <input name="is_vaccinated" type="checkbox" class="form-check-input" id="vacc"
               <?= ($pet['is_vaccinated']??'f')==='t'?'checked':'' ?>/>
        <label class="form-check-label fw-semibold" for="vacc">Vaccinated</label>
      </div>
    </div>
    <?php if($action==='add'): ?>
    <div class="col-12">
      <label class="form-label fw-semibold">Species (EER Subclass)</label>
      <select name="species" class="form-select" id="specSel" onchange="showSubform()">
        <option value="Dog">Dog</option><option value="Cat">Cat</option><option value="Other">Other Animal</option>
      </select>
    </div>
    <!-- Dog sub-attrs -->
    <div id="dogForm" class="col-12"><div class="row g-2">
      <div class="col-md-4"><label class="form-label">Size</label>
        <select name="size" class="form-select"><option>Small</option><option selected>Medium</option><option>Large</option></select></div>
      <div class="col-md-4 d-flex align-items-end pb-1">
        <div class="form-check"><input name="is_trained" type="checkbox" class="form-check-input" id="tr"/>
        <label class="form-check-label" for="tr">Is Trained</label></div></div>
    </div></div>
    <!-- Cat sub-attrs -->
    <div id="catForm" class="col-12 d-none"><div class="row g-2">
      <div class="col-md-4"><label class="form-label">Fur Length</label>
        <select name="fur_length" class="form-select"><option>Short</option><option>Medium</option><option>Long</option></select></div>
      <div class="col-md-4 d-flex align-items-end pb-1">
        <div class="form-check"><input name="is_indoor" type="checkbox" class="form-check-input" id="ind" checked/>
        <label class="form-check-label" for="ind">Indoor</label></div></div>
    </div></div>
    <!-- Other sub-attrs -->
    <div id="otherForm" class="col-12 d-none">
      <label class="form-label">Species Name</label>
      <input name="species_name" class="form-control" placeholder="e.g. Rabbit, Parrot"/></div>
    <?php endif; ?>
  </div><!-- row -->
  <div class="sql-box my-3">
    <?= $action==='add'
      ? "INSERT INTO Pets (pet_id, name, breed, age, gender, weight_kg,\n    intake_date, adoption_status, microchip_id, is_vaccinated, shelter_id)\nVALUES (...);"
      : "UPDATE Pets SET name=..., breed=..., age=..., gender=...,\n    adoption_status=..., is_vaccinated=...\nWHERE pet_id = '".htmlspecialchars($pet['pet_id']??'')."';" ?>
  </div>
  <div class="d-flex gap-3 mt-2">
    <button class="btn <?=$btnCol?> flex-fill py-2">
      <i class="bi bi-<?= $action==='add'?'plus-circle':'save' ?> me-2"></i><?= $action==='add'?'Add Pet':'Save Changes' ?>
    </button>
    <a href="pets.php" class="btn btn-outline-secondary flex-fill py-2"><i class="bi bi-arrow-left me-2"></i>Cancel</a>
  </div>
</form>
</div></div></div></div>
<script>
function showSubform(){
  var v=document.getElementById('specSel').value;
  document.getElementById('dogForm').classList.toggle('d-none',v!=='Dog');
  document.getElementById('catForm').classList.toggle('d-none',v!=='Cat');
  document.getElementById('otherForm').classList.toggle('d-none',v!=='Other');
}
</script>
<?php require 'footer.php'; exit; } // end add/edit

// ── LIST (READ) ──────────────────────────────────────────────────────────────
$search_col = $_GET['col'] ?? 'name';
$search_val = trim($_GET['val'] ?? '');
$allowed = ['name','breed','adoption_status','gender','pet_id'];
if (!in_array($search_col,$allowed)) $search_col='name';

if ($search_val !== '') {
    $sv = esc($conn,$search_val);
    $res = pg_query($conn,"SELECT p.*, s.shelter_name,
           CASE WHEN d.pet_id IS NOT NULL THEN 'Dog'
                WHEN c.pet_id IS NOT NULL THEN 'Cat'
                WHEN o.pet_id IS NOT NULL THEN 'Other' ELSE '—' END AS species
           FROM Pets p
           LEFT JOIN Shelter s ON p.shelter_id=s.shelter_id
           LEFT JOIN Dog d ON p.pet_id=d.pet_id
           LEFT JOIN Cat c ON p.pet_id=c.pet_id
           LEFT JOIN Other_Animal o ON p.pet_id=o.pet_id
           WHERE CAST(p.{$search_col} AS TEXT) ILIKE '%{$sv}%'
           ORDER BY p.pet_id");
} else {
    $res = pg_query($conn,"SELECT p.*, s.shelter_name,
           CASE WHEN d.pet_id IS NOT NULL THEN 'Dog'
                WHEN c.pet_id IS NOT NULL THEN 'Cat'
                WHEN o.pet_id IS NOT NULL THEN 'Other' ELSE '—' END AS species
           FROM Pets p
           LEFT JOIN Shelter s ON p.shelter_id=s.shelter_id
           LEFT JOIN Dog d ON p.pet_id=d.pet_id
           LEFT JOIN Cat c ON p.pet_id=c.pet_id
           LEFT JOIN Other_Animal o ON p.pet_id=o.pet_id
           ORDER BY p.pet_id");
}
$pets = pg_fetch_all($res) ?: [];
require 'header.php';
?>

<div class="page-header">
  <h4><i class="bi bi-paw me-2"></i>Pets — CRUD Operations</h4>
  <small>Manage Pets table &nbsp;|&nbsp; Includes Dog / Cat / Other_Animal subclasses (EER Specialization)</small>
</div>

<!-- Action buttons -->
<div class="row g-3 mb-4">
  <div class="col-md-3"><a href="pets.php?action=add" class="btn btn-create w-100 py-3 rounded-3 text-center">
    <div style="font-size:1.8rem;"><i class="bi bi-plus-circle-fill"></i></div>
    <strong>CREATE</strong><br/><small>Add new pet</small></a></div>
  <div class="col-md-3"><div class="btn btn-read w-100 py-3 rounded-3 text-center" style="cursor:default;">
    <div style="font-size:1.8rem;"><i class="bi bi-search"></i></div>
    <strong>READ</strong><br/><small>View &amp; search records</small></div></div>
  <div class="col-md-3"><div class="btn btn-update w-100 py-3 rounded-3 text-center" style="cursor:default;">
    <div style="font-size:1.8rem;"><i class="bi bi-pencil-square"></i></div>
    <strong>UPDATE</strong><br/><small>Click Edit on any row</small></div></div>
  <div class="col-md-3"><div class="btn btn-delete w-100 py-3 rounded-3 text-center" style="cursor:default;">
    <div style="font-size:1.8rem;"><i class="bi bi-trash3-fill"></i></div>
    <strong>DELETE</strong><br/><small>Click Delete on any row</small></div></div>
</div>

<!-- Search -->
<div class="card mb-4">
  <div class="card-header bg-primary text-white"><i class="bi bi-funnel me-2"></i>Filter / Search</div>
  <div class="card-body">
    <form method="GET" class="row g-3 align-items-end">
      <input type="hidden" name="action" value="list"/>
      <div class="col-md-3">
        <label class="form-label fw-semibold">Column</label>
        <select name="col" class="form-select">
          <?php foreach(['pet_id'=>'Pet ID','name'=>'Name','breed'=>'Breed','adoption_status'=>'Status','gender'=>'Gender'] as $v=>$l): ?>
          <option value="<?=$v?>" <?=$search_col===$v?'selected':''?>><?=$l?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-6">
        <label class="form-label fw-semibold">Search Value</label>
        <input name="val" class="form-control" value="<?= htmlspecialchars($search_val) ?>" placeholder="e.g. Available, Labrador..."/>
      </div>
      <div class="col-md-3 d-flex gap-2">
        <button class="btn btn-read flex-fill"><i class="bi bi-search me-1"></i>Search</button>
        <a href="pets.php" class="btn btn-outline-secondary flex-fill"><i class="bi bi-x-circle me-1"></i>Clear</a>
      </div>
    </form>
  </div>
</div>

<!-- Table -->
<div class="card">
  <div class="card-header d-flex justify-content-between" style="background:#1a3a5c;color:#fff;">
    <span><i class="bi bi-table me-2"></i>Pets Table <?= $search_val?"— filtered by <em>{$search_col}</em> = \"<em>{$search_val}</em>\"":'' ?></span>
    <span class="badge bg-light text-dark"><?= count($pets) ?> record(s)</span>
  </div>
  <div class="card-body p-0">
  <?php if($pets): ?>
  <div class="table-responsive">
  <table class="table table-hover table-bordered mb-0">
    <thead><tr>
      <th>Pet ID</th><th>Name</th><th>Breed</th><th>Species</th>
      <th>Age</th><th>Gender</th><th>Weight</th><th>Status</th>
      <th>Vaccinated</th><th>Shelter</th><th class="text-center">Actions</th>
    </tr></thead>
    <tbody>
    <?php foreach($pets as $p):
      $sColor=['Available'=>'badge-available','Adopted'=>'badge-adopted','Reserved'=>'badge-reserved'][$p['adoption_status']]??'bg-secondary';
    ?>
    <tr>
      <td><code><?= htmlspecialchars($p['pet_id']) ?></code></td>
      <td><strong><?= htmlspecialchars($p['name']) ?></strong></td>
      <td><?= htmlspecialchars($p['breed']) ?></td>
      <td><span class="badge bg-secondary"><?= $p['species'] ?></span></td>
      <td><?= $p['age'] ?> yr</td>
      <td><?= $p['gender'] ?></td>
      <td><?= $p['weight_kg'] ?? '—' ?> kg</td>
      <td><span class="badge <?= $sColor ?>"><?= $p['adoption_status'] ?></span></td>
      <td class="text-center"><?= $p['is_vaccinated']==='t'
        ? '<i class="bi bi-check-circle-fill text-success"></i>'
        : '<i class="bi bi-x-circle-fill text-danger"></i>' ?></td>
      <td><?= htmlspecialchars($p['shelter_name']??'—') ?></td>
      <td class="text-center text-nowrap">
        <a href="pets.php?action=edit&id=<?= urlencode($p['pet_id']) ?>" class="btn btn-update btn-sm me-1"><i class="bi bi-pencil-square me-1"></i>Edit</a>
        <a href="pets.php?action=delete&id=<?= urlencode($p['pet_id']) ?>" class="btn btn-delete btn-sm"><i class="bi bi-trash3 me-1"></i>Del</a>
      </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
  <?php else: ?>
  <div class="text-center py-5 text-muted">
    <i class="bi bi-inbox" style="font-size:3rem;"></i>
    <p class="mt-2">No records found.</p>
  </div>
  <?php endif; ?>
  </div>
</div>

<?php pg_close($conn); require 'footer.php'; ?>
