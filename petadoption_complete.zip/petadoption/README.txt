================================================================
PET ADOPTION AND CARE SYSTEM — CRUD Application
RDBMS Lab CA Activity 1
Technology: PHP (XAMPP) + PostgreSQL (pgAdmin)
================================================================

SETUP INSTRUCTIONS — READ CAREFULLY
================================================================

STEP 1: SETUP POSTGRESQL DATABASE IN pgAdmin
─────────────────────────────────────────────
1. Open pgAdmin 4
2. Right-click Databases → Create → Database
3. Name it: pet_adoption_db
4. Click Save
5. Expand Databases → pet_adoption_db → right-click → Query Tool
6. Open setup.sql (this folder) → paste entire contents → click Execute (F5)
7. You will see a results table showing all 22 tables with row counts
8. Your database is ready.

STEP 2: ENABLE PostgreSQL IN XAMPP PHP
─────────────────────────────────────────────
1. Open XAMPP Control Panel
2. Click Config next to Apache → PHP (php.ini)
3. Search for: ;extension=pgsql
   Remove the semicolon → extension=pgsql
4. Search for: ;extension=pdo_pgsql
   Remove the semicolon → extension=pdo_pgsql
5. Save php.ini
6. Restart Apache in XAMPP Control Panel

STEP 3: COPY PROJECT FILES
─────────────────────────────────────────────
1. Copy the entire petadoption/ folder to:
   C:\xampp\htdocs\petadoption\

STEP 4: UPDATE YOUR PASSWORD
─────────────────────────────────────────────
1. Open petadoption/db.php
2. Line 9: Change 'your_password' to your actual pgAdmin/PostgreSQL password
   define('DB_PASS', 'your_actual_password');

STEP 5: START THE APPLICATION
─────────────────────────────────────────────
1. Open XAMPP Control Panel
2. Start Apache
3. Make sure PostgreSQL is running (check pgAdmin — server should show connected)
4. Open your browser and go to:
   http://localhost/petadoption/

================================================================
WHAT THE APPLICATION COVERS
================================================================

Pages:
  index.php       → Dashboard showing all table counts and all 11 relationships
  pets.php        → Full CRUD for Pets + Dog/Cat/Other_Animal subclasses
  adopters.php    → Full CRUD for Adopters + Individual/Organization subclasses
  applications.php → CRUD for Adoption_Applications + trigger demonstration
  appointments.php → CRUD for Appointments + BEFORE trigger demonstration
  providers.php   → CRUD for Pet_Care_Providers + Vet/Groomer subclasses
  staff.php       → CRUD for Staff + Volunteer/Employee + Staff_Pet M:N table
  donations.php   → CRUD for Donation
  medical.php     → CRUD for Medical_Records
  training.php    → CRUD for Training_Programs + Dog_Training M:N table
  views.php       → Shows all 3 SQL views live + audit log from trigger

Tables: 22 total (matches the expanded EER diagram)
Relationships: 11 (all from EER diagram)
Specializations: 4 (Pets, Adopters, Providers, Staff)
Triggers: 3 (trg_approval_status, trg_check_pet_status, trg_log_application)
Views: 3 (Available_Pets, Pending_Applications_View, Pet_Appointment_History)

================================================================
DEMO CHECKLIST FOR VIVA
================================================================

CREATE:   Go to pets.php → Add Pet → fill form → submit → success message
READ:     Home page → shows all records + search/filter by column
UPDATE:   Go to pets.php → click Edit on any pet → change field → see Before/After
DELETE:   Click Delete → see confirmation page with record → confirm → success
TRIGGER:  applications.php → change status to Approved → pets.php shows pet as Adopted
VIEWS:    views.php → shows live data from all 3 views
MODIFY:   ALTER TABLE Pets ADD COLUMN weight_kg DECIMAL(5,2); → already done in schema

================================================================
